<?php
include 'config.php';
include 'function.php';
$_SESSION["msg"] = "";
?>
<!DOCTYPE html>
<html>

<head>
	<title>
		Products
	</title>
	<link href="style.css" type="text/css" rel="stylesheet">
</head>

<body>
	<?php include 'header.php'; ?>

	<div id="main">
		<div id="products">
			<?php displayProducts(); ?>
		</div>

		<div id="cart">
		   <tbody>
			<p><?php $_SESSION["msg"]; ?></p>
			<?php displayCart();
			//print_r($_SESSION["cart"]);
			?>
			
		</div>
	</div>

	<?php include 'footer.php'; ?>
</body>

</html>