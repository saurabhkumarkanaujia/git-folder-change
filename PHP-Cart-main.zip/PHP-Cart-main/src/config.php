<?php
session_start();
if (!isset($_SESSION["cart"])) {
	//if cart array is not set then create 
	$_SESSION["cart"] = array();
}

$_SESSION["products"] = array(
	array("id" => 101, "image" => "football.png", "name" => "Football", "price" => 150.00, "quantity" => 1),
	array("id" => 102, "image" => "tennis.png", "name" => "Tennis Ball", "price" => 120.00, "quantity" => 1),
	array("id" => 103, "image" => "basketball.png", "name" => "Basketball", "price" => 90.00, "quantity" => 1),
	array("id" => 104, "image" => "table-tennis.png", "name" => "Table tennis ball", "price" => 110.00, "quantity" => 1),
	array("id" => 105, "image" => "soccer.png", "name" => "Soccer", "price" => 80.00, "quantity" => 1),
);
?>