<?php
session_start();
include 'config.php';
include 'function.php';

if(isset($_GET))
{
    $id=$_GET["id"];
    removeItem($id);
}

function removeItem($id)
{
    if(count($_SESSION["cart"])==0)
    {
        $_SESSION["msg"]="Cart is Empty!!1";
       
        header("Location: products.php");
    
    }
    else{
        for($i=0; $i<count($_SESSION["cart"]); $i++)
        {
            if(trim($_SESSION["cart"][$i]["id"])==$id)
            {
                array_splice($_SESSION["cart"], $i, 1);
                
                header("Location: products.php");
            }
        }
    }
}
?>