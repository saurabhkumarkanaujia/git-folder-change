<?php
session_start();
include 'config.php';

if(isset($_POST))
{
    $quant=(int)$_POST["quantity"];
    $id=$_POST["id"];
    changeQuant($id, $quant);   
    
}

function changeQuant($id, $quant)
{
    for($i=0; $i<count($_SESSION["cart"]); $i++)
    {
        if(trim($_SESSION["cart"][$i]["id"])==$id)
        {
            $_SESSION["cart"][$i]["quantity"] = $quant;
            header("Location: products.php");
        }
    }
}

?>