
<?php
//session_start();
function displayProducts()
{//dynamically display the product list 
    foreach($_SESSION["products"] as $value)
    {
        echo "<div id='product-".$value["id"]."' class='product'>";
        echo    "<img src='images/".$value["image"]."'>";
        echo    "<h3 class='title'><a href='#'>".$value["name"]."</a></h3>";
        echo    "<span>Price: $".$value["price"]."</span>";
        echo    "<a class='add-to-cart' href='addcart.php?id=".$value["id"]."'>Add To Cart</a>";
        echo "</div>";            
    }
}


function displayCart()
{//dynamically create cart table and display
    if(count($_SESSION["cart"]) == 0)
    {
        echo "<h3>Cart is empty</h3>";
    }
    else{
        
        ?>
        <table id = "cart_view">
			<caption>Cart</caption>
        <thead>
          <tr>
             <th>Product ID</th>
             <th>Name</th>
             <th>Image</th>
             <th>Price</th>
             <th>Quantity</th>
            <th>Total Price</th>
           </tr></thead>
        <?php 

             foreach($_SESSION["cart"] as $product)
              {
                echo "<tr>";
                echo "<td>".$product["id"]."</td>";
                echo "<td>".$product["name"]."</td>";
                echo "<td><img src='images/".$product["image"]."'></td>";
                echo "<td>".$product["price"]."</td>";
                echo "<td><form action='updateqty.php' method='post'>
                <input type='number' placeholder='".$product["quantity"]."'
                name='quantity' style='width: 50px; height: 30px; font-size: 20px;' min='0'>
                <input type='hidden' name='id' value='".$product["id"]."' style='display:none;'>
                <input type='submit' value='UPDATE'></td>";
                echo "<td>".($product["price"]*$product["quantity"])."</td>";
                echo "<td><a href='removecart.php?id=".$product["id"]."' style='color: red;'>Remove Item</a></td>";
                echo "</tr>";
              }

              $totalPrice=0;
              $totalQuant=0;
             
              //foreach($_SESSION['cart'] as $i)
              for($i=0; $i<count($_SESSION["cart"]); $i++)
              {
                  //echo $_SESSION["cart"][$i]["price"]*$_SESSION["cart"][$i]["quantity"];
                $price=($_SESSION['cart'][$i]["price"]*$_SESSION['cart'][$i]["quantity"]);
                $quant=($_SESSION['cart'][$i]["quantity"]);
                $totalPrice += $price;
                $totalQuant += $quant;
              }
             ?>
            <tfoot>
             <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td>Total Quantity: <b><?php echo $totalQuant; ?></b></td>
                <td>Total Price: <b><?php echo $totalPrice; ?></b></td>
                <td></td>
            </tr></tfoot>
             </table>
             <?php
    }
    
}



?>