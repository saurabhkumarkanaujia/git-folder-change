<?php 
session_start();
include 'config.php';


if(isset($_GET))
{
    $id=$_GET["id"];
    $val=addToCart($id);   
    if($val==2)
    {
        header("Location: products.php");
    }
    else{
        header("Location: products.php");
    }

}


function addToCart($id)
{
   ///print_r($_SESSION["cart"]);
    if(count($_SESSION["cart"])==0)
    {
        addItem($id);
        return 1;
    }
    else{
        for($i=0; $i<count($_SESSION["cart"]); $i++)
        {
            if(trim($_SESSION["cart"][$i]["id"])==$id)
            {
                $_SESSION["cart"][$i]["quantity"] +=1;
                return 2;;
            }
        }
        addItem($id);
        return 1;
    }
    
}

function addItem($id)
{
    foreach($_SESSION["products"] as $product)
    {
        if($product["id"]==$id)
        {
            array_push($_SESSION["cart"], $product); 
           // print_r($_SESSION["cart"]);
        }
    } 
}


?>